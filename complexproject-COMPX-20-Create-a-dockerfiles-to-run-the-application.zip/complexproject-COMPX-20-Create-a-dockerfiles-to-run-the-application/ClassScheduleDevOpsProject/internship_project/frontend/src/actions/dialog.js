import * as actionTypes from './actionsType';

export const setIsOpenConfirmDialog = (payload) => ({
    type: actionTypes.SET_IS_OPEN_CONFIRM_DIALOG,
    payload,
});
