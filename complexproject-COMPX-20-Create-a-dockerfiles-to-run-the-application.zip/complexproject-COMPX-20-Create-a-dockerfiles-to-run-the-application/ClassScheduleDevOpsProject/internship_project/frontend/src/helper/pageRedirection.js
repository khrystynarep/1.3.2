import { GROUP_LIST_LINK } from '../constants/links';

export const goToGroupPage = (history) => {
    history.push(GROUP_LIST_LINK);
};
