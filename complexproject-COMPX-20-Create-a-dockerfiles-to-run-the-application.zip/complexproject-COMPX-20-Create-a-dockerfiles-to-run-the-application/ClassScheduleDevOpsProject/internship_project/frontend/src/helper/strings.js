export const firstStringLetterCapital = (str) => {
    return str.replace(/^\w/, (c) => c.toUpperCase());
};
