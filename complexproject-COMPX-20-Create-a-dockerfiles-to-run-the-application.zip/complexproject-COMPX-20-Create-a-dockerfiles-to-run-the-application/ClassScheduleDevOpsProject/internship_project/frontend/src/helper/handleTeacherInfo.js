export const handleTeacherInfo = (teacher) => {
    return `${teacher.surname} ${teacher.name} ${teacher.patronymic}(${teacher.position})`;
};
