import AdminRoute from './AdminRoute';
import UserRoute from './UserRoute';

export { AdminRoute, UserRoute };
