export const CLASS_DURATION = '1.3333333333333333333333333333';
export const GOOGLE = 'google';

export const MAX_LENGTH_50 = 50;
export const MAX_LENGTH_40 = 40;
export const GROUPED = 'групова';
