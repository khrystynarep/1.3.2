export const GROUP = 'group';
export const STUDENT = 'student';
