const temporaryScheduleRadioTypes = {
    SEMESTER: 'semester',
    FEW_DAYS: 'days',
    ONE_DAY: 'day',
};
export { temporaryScheduleRadioTypes };
