const snackbarMessage = (cardType, actionType) => {
    return `${cardType} was ${actionType} successfully`;
};
export { snackbarMessage };
