export const ADD_STUDENT_ACTION = 'add-student';
export const SHOW_STUDENTS_ACTION = 'show-students';
