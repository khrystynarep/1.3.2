const places = {
    TOGETHER: 'auditory+online',
    AUDITORY: 'auditory',
    ONLINE: 'online',
};
export { places };
