const languageShorthands = {
    Ukrainian: 'uk',
    English: 'en',
};

export { languageShorthands };
