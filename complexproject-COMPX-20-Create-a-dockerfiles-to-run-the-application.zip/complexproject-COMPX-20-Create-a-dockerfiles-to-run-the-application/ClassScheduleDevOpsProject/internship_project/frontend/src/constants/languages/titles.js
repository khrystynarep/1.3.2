const languageTitles = {
    English: 'English',
    Ukrainian: 'Українська',
};

export { languageTitles };
