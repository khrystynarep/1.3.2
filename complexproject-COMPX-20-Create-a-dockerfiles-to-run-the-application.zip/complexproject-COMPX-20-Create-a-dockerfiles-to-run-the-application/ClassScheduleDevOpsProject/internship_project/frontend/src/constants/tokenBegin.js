const TOKEN_BEGIN = 'Bearer_';
export { TOKEN_BEGIN };
