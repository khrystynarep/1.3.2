const actionType = {
    CREATED: 'created',
    DELETED: 'deleted',
    UPDATED: 'updated',
    ADD: 'add',
};
export { actionType };
