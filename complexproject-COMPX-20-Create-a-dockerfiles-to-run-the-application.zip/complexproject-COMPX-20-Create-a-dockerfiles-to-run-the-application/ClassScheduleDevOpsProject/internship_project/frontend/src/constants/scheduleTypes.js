export const GROUP = 'group';
export const TEACHER = 'teacher';
export const FULL = 'full';
