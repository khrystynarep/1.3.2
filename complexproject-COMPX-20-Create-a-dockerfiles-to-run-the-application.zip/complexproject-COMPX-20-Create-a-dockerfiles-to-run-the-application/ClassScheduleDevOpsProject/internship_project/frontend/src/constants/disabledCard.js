export const disabledCard = {
    SHOW: 'show',
    HIDE: 'hide',
};

export const hasDisabled = 'disable';
