const SCHEDULE_TYPES = {
    GROUP: 'group',
    TEACHER: 'teacher',
    FULL: 'full',
};

export { SCHEDULE_TYPES };
