const cssClasses = {
    SCHEDULE_BOARD: 'schedule-board',
    IN_BOARD_SECTION: 'in-board-section',
    IN_BOARD_CARD: 'in-board-card',
    MORE_ICON: 'more-icon',
};

export { cssClasses };
