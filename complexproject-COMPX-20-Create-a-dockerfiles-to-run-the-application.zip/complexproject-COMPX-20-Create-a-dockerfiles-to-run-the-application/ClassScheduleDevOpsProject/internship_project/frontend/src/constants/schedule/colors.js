const colors = {
    POSSIBILITY: '#f7f7c1',
    DANGER: '#ff5e54',
    ALLOW: '#68f271',
    NOTHING: '#fff',
    BORDER: '#d3d4d5',
};

export { colors };
