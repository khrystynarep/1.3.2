export const userRoles = {
    USER: 'ROLE_USER',
    MANAGER: 'ROLE_MANAGER',
    TEACHER: 'ROLE_TEACHER',
};
